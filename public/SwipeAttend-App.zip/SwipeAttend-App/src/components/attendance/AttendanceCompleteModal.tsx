import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { AttendanceSession } from '../../types/attendance';
import { Check, ArrowRight, FileText, Calendar } from 'lucide-react';
import { formatClassDate } from '../../utils/dateUtils';

interface AttendanceCompleteModalProps {
  session: AttendanceSession;
  onViewSummary: () => void;
  onSaveAndFinish: () => void;
}

export const AttendanceCompleteModal: React.FC<AttendanceCompleteModalProps> = ({
  session,
  onViewSummary,
  onSaveAndFinish,
}) => {
  const total = session.totalStudents || Object.keys(session.records).length || 58;
  const present = session.presentCount || Object.values(session.records).filter((s) => s === 'present').length;
  const absent = session.absentCount || Object.values(session.records).filter((s) => s === 'absent').length;
  const percentage = total > 0 ? ((present / total) * 100).toFixed(1) : '0.0';

  useEffect(() => {
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 },
      colors: ['#10B981', '#8B5CF6', '#3B82F6', '#F59E0B'],
    });
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-md bg-[#0F1424] border border-white/10 rounded-2xl sm:rounded-3xl p-5 sm:p-7 text-center shadow-2xl shadow-emerald-950/40 overflow-hidden my-auto max-h-[94vh] flex flex-col justify-between">
        {/* Glow backdrop */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Big Animated Success Checkmark Ring */}
        <div className="relative mx-auto w-14 h-14 sm:w-18 sm:h-18 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 shadow-xl shadow-emerald-500/30 mb-3 sm:mb-4 animate-bounce-short shrink-0">
          <Check className="w-7 h-7 sm:w-9 sm:h-9 stroke-[3]" />
        </div>

        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white font-['Plus_Jakarta_Sans'] tracking-tight">
            Attendance Complete!
          </h2>
          <p className="mt-1 text-xs sm:text-sm font-semibold text-slate-300 truncate">
            {session.subjectName}
          </p>
          <p className="text-[11px] sm:text-xs text-slate-400 truncate">
            {session.classroomName}
          </p>
          <div className="mt-2 flex items-center justify-center gap-1.5">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-violet-500/15 border border-violet-500/25 text-violet-300 text-[11px] font-mono">
              <Calendar className="w-3 h-3 text-violet-400" />
              <span>{formatClassDate(session.date, true)}</span>
            </span>
          </div>
        </div>

        {/* 4-Metric Grid */}
        <div className="grid grid-cols-4 gap-1.5 sm:gap-2 my-4 sm:my-5 bg-[#141A2E] border border-white/8 rounded-xl sm:rounded-2xl p-2.5 sm:p-3.5 shrink-0">
          <div className="flex flex-col items-center">
            <span className="text-base sm:text-xl font-extrabold text-white font-mono">
              {total}
            </span>
            <span className="text-[9px] sm:text-[10px] uppercase font-bold text-slate-400 mt-0.5">
              Total
            </span>
          </div>

          <div className="flex flex-col items-center border-l border-white/10">
            <span className="text-base sm:text-xl font-extrabold text-emerald-400 font-mono">
              {present}
            </span>
            <span className="text-[9px] sm:text-[10px] uppercase font-bold text-slate-400 mt-0.5">
              Present
            </span>
          </div>

          <div className="flex flex-col items-center border-l border-white/10">
            <span className="text-base sm:text-xl font-extrabold text-red-400 font-mono">
              {absent}
            </span>
            <span className="text-[9px] sm:text-[10px] uppercase font-bold text-slate-400 mt-0.5">
              Absent
            </span>
          </div>

          <div className="flex flex-col items-center border-l border-white/10">
            <span className="text-base sm:text-xl font-extrabold text-violet-400 font-mono">
              {percentage}%
            </span>
            <span className="text-[9px] sm:text-[10px] uppercase font-bold text-slate-400 mt-0.5">
              Rate
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 sm:space-y-2.5 shrink-0">
          <button
            onClick={onViewSummary}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#1A223B] border border-white/10 text-white font-semibold text-xs sm:text-sm hover:bg-[#212B4A] transition-colors cursor-pointer min-h-[44px]"
          >
            <FileText className="w-4 h-4 text-violet-400" />
            <span>View Summary & Edit</span>
          </button>

          <button
            onClick={onSaveAndFinish}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-violet-600/30 transition-all cursor-pointer min-h-[44px]"
          >
            <span>Save & Finish</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
