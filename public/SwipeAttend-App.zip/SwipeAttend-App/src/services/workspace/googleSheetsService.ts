import { AttendanceSession, Student, Classroom, Subject } from '../../types/attendance';
import { GoogleWorkspaceResult } from './types';

/**
 * Creates a formatted Google Sheet for a single attendance session.
 */
export async function exportSessionToGoogleSheet(
  session: AttendanceSession,
  students: Student[],
  token: string
): Promise<GoogleWorkspaceResult> {
  try {
    const title = `SwipeAttend - ${session.subjectName} - ${session.date}`;

    // 1. Create Spreadsheet
    const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        properties: {
          title,
        },
      }),
    });

    if (!createRes.ok) {
      const err = await createRes.json().catch(() => ({}));
      throw new Error(err.error?.message || `Failed to create Google Sheet (${createRes.status})`);
    }

    const spreadsheet = await createRes.json();
    const spreadsheetId = spreadsheet.spreadsheetId;
    const spreadsheetUrl = spreadsheet.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

    // 2. Prepare Rows
    const relevantStudents = students.filter(
      (s) => s.classroomId === session.classroomId || session.records[s.id] !== undefined
    );
    const sortedStudents = [...relevantStudents].sort((a, b) => {
      const numA = parseInt(a.rollNo.replace(/\D/g, ''), 10);
      const numB = parseInt(b.rollNo.replace(/\D/g, ''), 10);
      if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
      return a.rollNo.localeCompare(b.rollNo);
    });

    const values: (string | number)[][] = [
      ['BIRSA INSTITUTE OF TECHNOLOGY (BIT) SINDRI'],
      ['ATTENDANCE SESSION RECORD — SwipeAttend Cloud System'],
      [''],
      ['Subject:', session.subjectName, '', 'Date:', session.date],
      ['Classroom:', session.classroomName, '', 'Period:', `Period ${session.period}`],
      ['Faculty:', session.markedBy || 'Faculty In-Charge', '', 'Session Type:', session.sessionType?.toUpperCase() || 'SWIPE'],
      [''],
      ['#', 'Roll No', 'Student Name', 'College ID', 'Attendance Status', 'Method', 'Timestamp'],
    ];

    sortedStudents.forEach((std, idx) => {
      const status = session.records[std.id] || 'unmarked';
      const meta = session.studentMetadata?.[std.id];
      values.push([
        idx + 1,
        std.rollNo,
        std.name,
        std.studentId,
        status.toUpperCase(),
        meta?.method || (session.sessionType === 'qr' ? 'QR Code' : 'Swipe Arena'),
        meta?.timestamp || '-',
      ]);
    });

    // Summary statistics block
    const presentCount = sortedStudents.filter((s) => session.records[s.id] === 'present').length;
    const absentCount = sortedStudents.filter((s) => session.records[s.id] === 'absent').length;
    const totalCount = sortedStudents.length;
    const pct = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0;

    values.push(['']);
    values.push(['SUMMARY STATISTICS', '', '', '', '', '', '']);
    values.push(['Total Enrolled:', totalCount, '', 'Total Present:', presentCount, 'Present %:', `${pct}%`]);
    values.push(['Total Absent:', absentCount, '', '', '', '', '']);
    values.push(['Generated automatically by SwipeAttend BIT Sindri System at:', new Date().toLocaleString()]);

    // 3. Populate Values via append
    const updateRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Sheet1!A1?valueInputOption=USER_ENTERED`,
      {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          range: 'Sheet1!A1',
          majorDimension: 'ROWS',
          values,
        }),
      }
    );

    if (!updateRes.ok) {
      const err = await updateRes.json().catch(() => ({}));
      throw new Error(err.error?.message || `Failed to populate Google Sheet (${updateRes.status})`);
    }

    return {
      success: true,
      id: spreadsheetId,
      url: spreadsheetUrl,
      title,
    };
  } catch (err: any) {
    console.error('Error in exportSessionToGoogleSheet:', err);
    return {
      success: false,
      error: err.message || 'Unknown error exporting to Google Sheets',
    };
  }
}

/**
 * Creates a cumulative multi-column classroom attendance spreadsheet in Google Sheets.
 */
export async function exportClassroomSummaryToGoogleSheet(
  classroom: Classroom,
  subjects: Subject[],
  sessions: AttendanceSession[],
  students: Student[],
  token: string
): Promise<GoogleWorkspaceResult> {
  try {
    const title = `SwipeAttend Roster - ${classroom.name}`;

    const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        properties: {
          title,
        },
      }),
    });

    if (!createRes.ok) {
      const err = await createRes.json().catch(() => ({}));
      throw new Error(err.error?.message || `Failed to create Google Sheet (${createRes.status})`);
    }

    const spreadsheet = await createRes.json();
    const spreadsheetId = spreadsheet.spreadsheetId;
    const spreadsheetUrl = spreadsheet.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

    const classStudents = students.filter((s) => s.classroomId === classroom.id);
    const sortedStudents = [...classStudents].sort((a, b) => {
      const numA = parseInt(a.rollNo.replace(/\D/g, ''), 10);
      const numB = parseInt(b.rollNo.replace(/\D/g, ''), 10);
      if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
      return a.rollNo.localeCompare(b.rollNo);
    });

    const completedSessions = sessions.filter(
      (s) => s.classroomId === classroom.id && s.status === 'completed'
    );

    const values: (string | number)[][] = [
      ['BIRSA INSTITUTE OF TECHNOLOGY (BIT) SINDRI'],
      [`CUMULATIVE ATTENDANCE ROSTER — ${classroom.name}`],
      ['Department:', classroom.department, 'Academic Year:', classroom.academicYear, 'Threshold:', `${classroom.attendanceThreshold}%`],
      ['Total Completed Lectures:', completedSessions.length, 'Enrolled Strength:', sortedStudents.length],
      [''],
      ['#', 'Roll No', 'Student Name', 'College ID', 'Attended', 'Total Held', 'Attendance %', 'Status (Threshold)'],
    ];

    sortedStudents.forEach((std, idx) => {
      let attended = 0;
      let held = 0;
      completedSessions.forEach((sess) => {
        const st = sess.records[std.id];
        if (st === 'present') {
          attended++;
          held++;
        } else if (st === 'absent') {
          held++;
        }
      });

      const pct = held > 0 ? Math.round((attended / held) * 100) : 0;
      const isDefaulter = pct < classroom.attendanceThreshold;

      values.push([
        idx + 1,
        std.rollNo,
        std.name,
        std.studentId,
        attended,
        held,
        `${pct}%`,
        isDefaulter ? 'WARNING (< 75%)' : 'Eligible',
      ]);
    });

    await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Sheet1!A1?valueInputOption=USER_ENTERED`,
      {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          range: 'Sheet1!A1',
          majorDimension: 'ROWS',
          values,
        }),
      }
    );

    return {
      success: true,
      id: spreadsheetId,
      url: spreadsheetUrl,
      title,
    };
  } catch (err: any) {
    console.error('Error in exportClassroomSummaryToGoogleSheet:', err);
    return {
      success: false,
      error: err.message || 'Failed to export classroom to Google Sheets',
    };
  }
}
